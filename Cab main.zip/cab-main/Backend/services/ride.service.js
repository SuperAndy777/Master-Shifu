const rideModel = require('../models/ride.model');
const mapService = require('./maps.service');
const bcrypt = require('bcrypt');
const crypto = require('crypto');

async function getFare(pickup, destination) {
    if (!pickup || !destination) {
        throw new Error('Pickup and destination are required');
    }

    let distanceTime;
    try {
        distanceTime = await mapService.getDistanceTime(pickup, destination);
    } catch (error) {
        console.error('Error getting distance and time from Google Maps API:', error);
        // Provide default values if the API call fails
        distanceTime = {
            distance: { value: 5000, text: '5 km' },
            duration: { value: 900, text: '15 mins' }
        };
    }

    const baseFare = {
        auto: 30,
        car: 50,
        moto: 20
    };

    const perKmRate = {
        auto: 10,
        car: 15,
        moto: 8
    };

    const perMinuteRate = {
        auto: 2,
        car: 3,
        moto: 1.5
    };

    const fare = {
        auto: Math.round(baseFare.auto + ((distanceTime.distance.value / 1000) * perKmRate.auto) + ((distanceTime.duration.value / 60) * perMinuteRate.auto)),
        car: Math.round(baseFare.car + ((distanceTime.distance.value / 1000) * perKmRate.car) + ((distanceTime.duration.value / 60) * perMinuteRate.car)),
        moto: Math.round(baseFare.moto + ((distanceTime.distance.value / 1000) * perKmRate.moto) + ((distanceTime.duration.value / 60) * perMinuteRate.moto))
    };

    return fare;
}

module.exports.getFare = getFare;


function getOtp(num) {
    function generateOtp(num) {
        const otp = crypto.randomInt(Math.pow(10, num - 1), Math.pow(10, num)).toString();
        return otp;
    }
    return generateOtp(num);
}


module.exports.createRide = async ({
    user, pickup, destination, vehicleType
}) => {
    if (!user || !pickup || !destination || !vehicleType) {
        throw new Error('All fields are required');
    }

    try {
        console.log('Getting coordinates for pickup:', pickup);
        const pickupCoords = await mapService.getAddressCoordinate(pickup);
        console.log('Getting coordinates for destination:', destination);
        const destinationCoords = await mapService.getAddressCoordinate(destination);

        if (!pickupCoords || !destinationCoords) {
            throw new Error('Failed to get coordinates for pickup or destination');
        }

        // Get distance and time for fare calculation
        console.log('Calculating distance and time between locations');
        const distanceTime = await mapService.getDistanceTime(pickup, destination);
        
        // Calculate fare based on distance and vehicle type
        const baseFare = {
            'auto': 30,
            'car': 50,
            'bike': 20
        }[vehicleType] || 30;

        const distanceInKm = distanceTime.distance?.value ? distanceTime.distance.value / 1000 : 5;
        const fare = Math.round(baseFare + (distanceInKm * 12));

        console.log('Creating ride with calculated fare:', fare);
        // Create the ride with location data
        const ride = await rideModel.create({
            user,
            pickup: {
                address: pickup,
                location: {
                    lat: pickupCoords.lat,
                    lng: pickupCoords.lng
                }
            },
            destination: {
                address: destination,
                location: {
                    lat: destinationCoords.lat,
                    lng: destinationCoords.lng
                }
            },
            fare,
            vehicleType,
            status: 'pending'
        });

        console.log('Ride created successfully:', ride._id);
        return ride;
    } catch (error) {
        console.error('Error creating ride:', error.message);
        throw error;
    }
}

module.exports.confirmRide = async ({
    rideId, captain
}) => {
    if (!rideId) {
        throw new Error('Ride id is required');
    }

    if (!captain || !captain._id) {
        throw new Error('Captain authentication required');
    }

    // First check if the ride exists and is available
    const existingRide = await rideModel.findOne({
        _id: rideId,
        status: 'pending' // Only allow confirming pending rides
    });

    if (!existingRide) {
        throw new Error('Ride not found or already taken');
    }

    try {
        // Update the ride status to accepted and assign the captain
        const updatedRide = await rideModel.findOneAndUpdate(
            {
                _id: rideId,
                status: 'pending' // Double check to prevent race conditions
            },
            {
                status: 'accepted',
                captain: captain._id
            },
            {
                new: true,
                runValidators: true
            }
        ).populate('user').populate('captain').select('+otp');

        if (!updatedRide) {
            throw new Error('Failed to confirm ride. It may have been taken by another captain.');
        }

        console.log(`Ride ${rideId} confirmed by captain ${captain._id}`);
        return updatedRide;
    } catch (error) {
        console.error('Error confirming ride:', error);
        throw new Error('Failed to confirm ride: ' + error.message);
    }
}

module.exports.startRide = async ({ rideId, otp, captain }) => {
    if (!rideId || !otp) {
        throw new Error('Ride ID and OTP are required');
    }

    if (!captain || !captain._id) {
        throw new Error('Captain authentication required');
    }

    // Validate OTP format
    if (!/^\d{6}$/.test(otp)) {
        throw new Error('Invalid OTP format. Must be 6 digits.');
    }

    console.log(`Looking for ride ${rideId} assigned to captain ${captain._id}`);

    const ride = await rideModel.findOne({
        _id: rideId,
        captain: captain._id  // Ensure the captain is assigned to this ride
    }).populate('user').populate('captain').select('+otp');

    if (!ride) {
        console.error(`Ride ${rideId} not found or not assigned to captain ${captain._id}`);
        throw new Error('Ride not found or you are not authorized for this ride');
    }

    console.log(`Found ride with status: ${ride.status}`);

    if (ride.status !== 'accepted') {
        console.error(`Invalid ride status: ${ride.status}. Expected 'accepted'`);
        throw new Error(`Ride must be in accepted status to start. Current status: ${ride.status}`);
    }

    console.log(`Validating OTP: ${otp} against stored OTP`);
    if (ride.otp !== otp) {
        console.error('OTP mismatch');
        throw new Error('Invalid OTP. Please check with the customer.');
    }

    try {
        console.log('Updating ride status to ongoing');
        const updatedRide = await rideModel.findOneAndUpdate(
            { 
                _id: rideId,
                captain: captain._id,  // Additional safety check
                status: 'accepted'     // Ensure status hasn't changed
            },
            { 
                status: 'ongoing',
                startTime: new Date()
            },
            { 
                new: true,
                runValidators: true
            }
        ).populate('user').populate('captain');

        if (!updatedRide) {
            console.error('Failed to update ride status');
            throw new Error('Failed to update ride status. The ride may have been cancelled or modified.');
        }

        console.log(`Successfully updated ride ${rideId} to ongoing status`);
        return updatedRide;
    } catch (error) {
        console.error('Error updating ride status:', error);
        throw new Error('Failed to start ride. Please try again.');
    }
}

module.exports.endRide = async ({ rideId, captain }) => {
    if (!rideId) {
        throw new Error('Ride id is required');
    }

    const ride = await rideModel.findOne({
        _id: rideId,
        captain: captain._id
    }).populate('user').populate('captain').select('+otp');

    if (!ride) {
        throw new Error('Ride not found');
    }

    if (ride.status !== 'ongoing') {
        throw new Error('Ride not ongoing');
    }

    await rideModel.findOneAndUpdate({
        _id: rideId
    }, {
        status: 'completed'
    })

    return ride;
}

