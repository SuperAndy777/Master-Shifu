const axios = require('axios');
const captainModel = require('../models/captain.model');
const dbscan = require('../utils/dbscan');
const rideModel = require('../models/ride.model');
const DBSCAN = require('dbscan');

const MAPS_API_KEY = process.env.GOOGLE_MAPS_API;

module.exports.getAddressCoordinate = async (address) => {
    try {
        if (!address) {
            console.log('No address provided for coordinate lookup');
            throw new Error('Address is required');
        }

        if (!MAPS_API_KEY) {
            console.log('No Google Maps API key found');
            throw new Error('Maps API key is required');
        }

        const response = await axios.get(`https://maps.googleapis.com/maps/api/geocode/json`, {
            params: {
                address,
                key: MAPS_API_KEY
            }
        });

        if (response.data.status === 'OK' && response.data.results.length > 0) {
            const location = response.data.results[0].geometry.location;
            console.log(`Found coordinates for address "${address}":`, location);
            return {
                lat: location.lat,
                lng: location.lng
            };
        }

        console.log(`No results found for address "${address}"`);
        throw new Error('Location not found');
    } catch (error) {
        console.error('Error getting coordinates:', error.message);
        // Return default coordinates for demo (Bangalore city center)
        return {
            lat: 12.9716,
            lng: 77.5946
        };
    }
};

module.exports.getDistanceTime = async (origin, destination) => {
    try {
        const response = await axios.get(`https://maps.googleapis.com/maps/api/distancematrix/json`, {
            params: {
                origins: origin,
                destinations: destination,
                key: MAPS_API_KEY
            }
        });

        if (response.data.status === 'OK' && response.data.rows[0].elements[0].status === 'OK') {
            return {
                distance: response.data.rows[0].elements[0].distance,
                duration: response.data.rows[0].elements[0].duration
            };
        }

        throw new Error('Distance calculation failed');
    } catch (error) {
        console.error('Error calculating distance:', error);
        // Return default values for demo
        return {
            distance: { text: '5 km', value: 5000 },
            duration: { text: '15 mins', value: 900 }
        };
    }
};

module.exports.getAutoCompleteSuggestions = async (input) => {
    if (!input) {
        throw new Error('query is required');
    }

    const apiKey = process.env.GOOGLE_MAPS_API;
    const url = `https://maps.googleapis.com/maps/api/place/autocomplete/json?input=${encodeURIComponent(input)}&key=${apiKey}`;

    try {
        console.log(`Fetching suggestions for: ${input}`);
        const response = await axios.get(url);
        console.log('Autocomplete API Response Status:', response.data.status);
        
        if (response.data.status === 'OK') {
            return response.data.predictions.map(prediction => prediction.description).filter(value => value);
        } else {
            console.error('Google Maps API Error:', response.data.status, response.data.error_message);
            // Return some default suggestions for demo purposes
            return [
                "New York, NY, USA",
                "Los Angeles, CA, USA",
                "Chicago, IL, USA",
                "Houston, TX, USA",
                "Phoenix, AZ, USA"
            ];
        }
    } catch (err) {
        console.error('Error fetching suggestions:', err.message);
        // Return some default suggestions for demo purposes
        return [
            "New York, NY, USA",
            "Los Angeles, CA, USA",
            "Chicago, IL, USA",
            "Houston, TX, USA",
            "Phoenix, AZ, USA"
        ];
    }
}

module.exports.getCaptainsInTheRadius = async (lat, lng, radius) => {
    // radius in km
    try {
        if (typeof lat !== 'number' || isNaN(lat) || typeof lng !== 'number' || isNaN(lng)) {
            console.error('Invalid coordinates provided:', { lat, lng });
            return [];
        }

        console.log(`Finding captains within ${radius}km of coordinates:`, { lat, lng });
        // Find captains where location is within the specified radius
        const captains = await captainModel.find({
            'location.lat': { $exists: true },
            'location.lng': { $exists: true }
        });
        
        console.log(`Found ${captains.length} captains with valid locations`);
        
        // Filter captains manually based on distance
        const captainsInRadius = captains.filter(captain => {
            if (!captain.location || 
                typeof captain.location.lat !== 'number' || 
                isNaN(captain.location.lat) || 
                typeof captain.location.lng !== 'number' || 
                isNaN(captain.location.lng)) {
                console.log(`Captain ${captain._id} has invalid location data:`, JSON.stringify(captain.location));
                return false;
            }
            
            // Calculate distance using Haversine formula
            const distance = calculateDistance(
                lat, 
                lng, 
                captain.location.lat, 
                captain.location.lng
            );
            
            const isInRadius = distance <= radius;
            if (isInRadius) {
                console.log(`Captain ${captain._id} is within radius (${distance.toFixed(2)}km)`);
            }
            return isInRadius;
        });
        
        console.log(`Found ${captainsInRadius.length} captains within ${radius}km radius`);
        return captainsInRadius;
    } catch (error) {
        console.error('Error finding captains in radius:', error.message);
        return [];
    }
}

// Helper function to calculate distance between two points using Haversine formula
function calculateDistance(lat1, lon1, lat2, lon2) {
    const R = 6371; // Radius of the earth in km
    const dLat = deg2rad(lat2 - lat1);
    const dLon = deg2rad(lon2 - lon1);
    const a = 
        Math.sin(dLat/2) * Math.sin(dLat/2) +
        Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) * 
        Math.sin(dLon/2) * Math.sin(dLon/2); 
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a)); 
    const distance = R * c; // Distance in km
    return distance;
}

function deg2rad(deg) {
    return deg * (Math.PI/180);
}

const getRiderLocations = async () => {
    try {
        const rides = await rideModel.find({ status: 'pending' }); // Fetch pending rides
        console.log(`Found ${rides.length} pending rides for hotspot detection`);
        
        // Extract coordinates from rides
        const locations = rides.map(ride => {
            if (ride.pickup && ride.pickup.lat && ride.pickup.lng) {
                return [ride.pickup.lat, ride.pickup.lng];
            }
            return null;
        }).filter(location => location !== null);

        console.log(`Extracted ${locations.length} valid locations for clustering`);
        return locations;
    } catch (error) {
        console.error('Error getting rider locations:', error);
        return [];
    }
};

// Function to detect hotspots using DBSCAN
module.exports.detectHotspots = async () => {
    try {
        // Get all pending rides
        const pendingRides = await rideModel.find({ status: 'pending' });
        console.log('Pending rides found:', pendingRides.length);
        
        if (!pendingRides || pendingRides.length === 0) {
            console.log('No pending rides found');
            return [];
        }

        // Extract pickup locations and validate them
        const locations = pendingRides
            .filter(ride => {
                // Ensure pickup location exists and has valid coordinates
                const hasValidPickup = ride.pickup && 
                    ride.pickup.location &&
                    typeof ride.pickup.location.lat === 'number' && 
                    !isNaN(ride.pickup.location.lat) &&
                    typeof ride.pickup.location.lng === 'number' &&
                    !isNaN(ride.pickup.location.lng);
                
                if (!hasValidPickup) {
                    console.log('Invalid pickup location for ride:', ride._id, 'Location:', JSON.stringify(ride.pickup.location));
                }
                return hasValidPickup;
            })
            .map(ride => ({
                lat: Number(ride.pickup.location.lat),
                lng: Number(ride.pickup.location.lng),
                rideId: ride._id,
                address: ride.pickup.address,
                fare: ride.fare,
                vehicleType: ride.vehicleType
            }));

        console.log('Valid locations found:', locations.length);

        if (locations.length === 0) {
            console.log('No valid locations found in pending rides');
            return [];
        }

        // Create a hotspot for each location
        const hotspots = locations.map(location => {
            console.log('Creating hotspot for location:', location);
            return {
                center: {
                    lat: location.lat,
                    lng: location.lng
                },
                intensity: 0.6, // Medium intensity for visibility
                radius: 500,   // 500 meters radius
                rideCount: 1,
                address: location.address,
                rideId: location.rideId,
                data: {
                    rideId: location.rideId,
                    address: location.address,
                    fare: location.fare,
                    vehicleType: location.vehicleType
                }
            };
        });

        console.log('Created hotspots:', hotspots.length);
        return hotspots;
    } catch (error) {
        console.error('Error detecting hotspots:', error);
        return [];
    }
};

module.exports = {
    getAddressCoordinate: module.exports.getAddressCoordinate,
    getDistanceTime: module.exports.getDistanceTime,
    getAutoCompleteSuggestions: module.exports.getAutoCompleteSuggestions,
    getCaptainsInTheRadius: module.exports.getCaptainsInTheRadius,
    detectHotspots: module.exports.detectHotspots
};