const rideService = require('../services/ride.service');
const { validationResult } = require('express-validator');
const mapService = require('../services/maps.service');
const { sendMessageToSocketId, broadcastMessage, getConnectedSockets } = require('../socket');
const rideModel = require('../models/ride.model');
const captainModel = require('../models/captain.model');
const dbscan = require('../utils/dbscan');


module.exports.createRide = async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
    }

    const { pickup, destination, vehicleType } = req.body;

    // Check if user is authenticated
    if (!req.user || !req.user._id) {
        return res.status(401).json({ message: 'User not authenticated' });
    }

    try {
        console.log(`Creating ride for user ${req.user._id} from ${pickup} to ${destination} with ${vehicleType}`);
        
        // Create the ride
        const ride = await rideService.createRide({ 
            user: req.user._id, 
            pickup, 
            destination, 
            vehicleType 
        });
        
        console.log(`Ride created with ID: ${ride._id}`);

        // Try to populate ride with user data
        let rideWithUser;
        try {
            rideWithUser = await rideModel.findOne({ _id: ride._id })
                .populate('user')
                .select('+otp');
            console.log(`Populated ride with user data: ${rideWithUser.user.fullname?.firstname || 'Unknown'}`);
        } catch (error) {
            console.error('Error populating ride with user data:', error);
            rideWithUser = ride; // Use unpopulated ride as fallback
        }
        
        // Send the ride data back to the client
        res.status(201).json(rideWithUser);

        // Try to get pickup coordinates
        let pickupCoordinates;
        try {
            pickupCoordinates = await mapService.getAddressCoordinate(pickup);
            console.log(`Pickup coordinates: ${JSON.stringify(pickupCoordinates)}`);
        } catch (error) {
            console.error('Error getting pickup coordinates:', error);
            // Use coordinates from the ride object if available
            pickupCoordinates = ride.pickup?.location || {
                ltd: 12.9716,
                lng: 77.5946
            };
            console.log(`Using fallback pickup coordinates: ${JSON.stringify(pickupCoordinates)}`);
        }

        // Try to find captains in radius
        let captainsInRadius = [];
        try {
            captainsInRadius = await mapService.getCaptainsInTheRadius(
                pickupCoordinates.ltd, 
                pickupCoordinates.lng, 
                2 // 2km radius
            );
            console.log(`Found ${captainsInRadius.length} captains in radius`);
        } catch (error) {
            console.error('Error finding captains in radius:', error);
        }

        // Get all connected sockets for logging
        const connectedSockets = getConnectedSockets();
        console.log(`Total connected sockets: ${connectedSockets.length}`);
        const captainSockets = Array.from(connectedSockets.values())
            .filter(socket => socket.type === 'captain');
        console.log(`Connected captain sockets: ${captainSockets.length}`);

        // Function to send ride notification to a captain
        const sendRideNotification = (captainSocketId) => {
            try {
                console.log(`Sending ride notification to captain socket ID ${captainSocketId}`);
                sendMessageToSocketId(captainSocketId, {
                    event: 'new-ride',
                    data: rideWithUser
                });
                return true;
            } catch (error) {
                console.error('Error sending message to captain:', error);
                return false;
            }
        };

        // First try to notify nearby captains
        let notificationsSent = 0;
        if (captainsInRadius.length > 0) {
            console.log(`Attempting to notify ${captainsInRadius.length} nearby captains`);
            captainsInRadius.forEach(captain => {
                if (captain.socketId && sendRideNotification(captain.socketId)) {
                    notificationsSent++;
                }
            });
        }

        // If no nearby captains were notified, try all connected captain sockets
        if (notificationsSent === 0 && captainSockets.length > 0) {
            console.log(`No nearby captains notified. Trying all ${captainSockets.length} connected captains`);
            captainSockets.forEach(socket => {
                if (socket.id && sendRideNotification(socket.id)) {
                    notificationsSent++;
                }
            });
        }

        console.log(`Successfully sent ride notifications to ${notificationsSent} captains`);

    } catch (err) {
        console.error('Error in createRide controller:', err);
        return res.status(500).json({ 
            message: 'Failed to create ride', 
            error: err.message 
        });
    }
};

module.exports.getFare = async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
    }

    const { pickup, destination } = req.query;

    try {
        const fare = await rideService.getFare(pickup, destination);
        return res.status(200).json(fare);
    } catch (err) {
        return res.status(500).json({ message: err.message });
    }
}

module.exports.confirmRide = async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({ 
            message: 'Validation failed',
            errors: errors.array() 
        });
    }

    const { rideId } = req.body;

    // Check if captain is authenticated
    if (!req.captain || !req.captain._id) {
        console.error('Captain not authenticated');
        return res.status(401).json({ message: 'Captain not authenticated' });
    }

    console.log(`Captain ${req.captain._id} attempting to confirm ride ${rideId}`);

    try {
        const ride = await rideService.confirmRide({ rideId, captain: req.captain });
        console.log(`Ride ${rideId} confirmed successfully`);

        // Send notification to user about ride confirmation
        if (ride.user && ride.user.socketId) {
            try {
                console.log(`Sending ride-confirmed notification to user ${ride.user._id}`);
                sendMessageToSocketId(ride.user.socketId, {
                    event: 'ride-confirmed',
                    data: ride
                });
            } catch (error) {
                console.error('Error sending ride confirmation notification:', error);
                // Continue even if notification fails
            }
        } else {
            console.log(`No socket ID found for user ${ride.user?._id}`);
        }

        return res.status(200).json(ride);
    } catch (err) {
        console.error('Error in confirmRide controller:', err);
        return res.status(err.status || 500).json({ 
            message: err.message || 'Failed to confirm ride',
            error: process.env.NODE_ENV === 'development' ? err.stack : undefined
        });
    }
}

module.exports.startRide = async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({ 
            message: 'Validation failed', 
            errors: errors.array() 
        });
    }

    const { rideId, otp } = req.query;
    
    // Check if captain is authenticated
    if (!req.captain || !req.captain._id) {
        console.error('Captain not authenticated');
        return res.status(401).json({ message: 'Captain not authenticated' });
    }

    console.log(`Starting ride ${rideId} with OTP ${otp} for captain ${req.captain._id}`);

    try {
        // First verify the ride exists and belongs to this captain
        const existingRide = await rideModel.findOne({
            _id: rideId,
            captain: req.captain._id,
            status: 'accepted'
        }).populate('user').populate('captain');

        if (!existingRide) {
            console.error(`Ride ${rideId} not found or not assigned to captain ${req.captain._id}`);
            return res.status(404).json({ 
                message: 'Ride not found or not assigned to you' 
            });
        }

        console.log(`Found ride: ${JSON.stringify({
            id: existingRide._id,
            status: existingRide.status,
            captain: existingRide.captain?._id,
            user: existingRide.user?._id
        })}`);

        const ride = await rideService.startRide({ 
            rideId, 
            otp, 
            captain: req.captain 
        });

        // Send notification to user that ride has started
        if (ride.user && ride.user.socketId) {
            try {
                console.log(`Sending ride-started notification to user ${ride.user._id} with socket ${ride.user.socketId}`);
                sendMessageToSocketId(ride.user.socketId, {
                    event: 'ride-started',
                    data: ride
                });
            } catch (error) {
                console.error('Error sending ride start notification:', error);
                // Continue even if notification fails
            }
        } else {
            console.log(`No socket ID found for user ${ride.user?._id}`);
        }

        console.log(`Successfully started ride ${rideId}`);
        return res.status(200).json(ride);
    } catch (err) {
        console.error('Error in startRide controller:', err);
        return res.status(err.status || 500).json({ 
            message: err.message || 'Failed to start ride',
            error: process.env.NODE_ENV === 'development' ? err.stack : undefined
        });
    }
}

module.exports.endRide = async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
    }

    const { rideId } = req.body;

    try {
        const ride = await rideService.endRide({ rideId, captain: req.captain });

        sendMessageToSocketId(ride.user.socketId, {
            event: 'ride-ended',
            data: ride
        })



        return res.status(200).json(ride);
    } catch (err) {
        return res.status(500).json({ message: err.message });
    } s
}

const detectHotspots = async () => {
    const riderLocations = await getRiderLocations();
    if (riderLocations.length === 0) return []; 

    try {
        // DBSCAN clustering with parameters:
        // eps: 0.01 (~1 km)
        // minPoints: 5 (requires at least 5 points to form a cluster)
        const dbscanClusters = dbscan(riderLocations, 0.01, 5);
        // ...
    } catch (err) {
        console.error('Error in detectHotspots:', err);
        return [];
    }
};