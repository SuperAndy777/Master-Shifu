const socketIo = require('socket.io');
const userModel = require('./models/user.model');
const captainModel = require('./models/captain.model');
const mapService = require('./services/maps.service'); // Import mapService

let io;
let connectedSockets = new Map(); // Track connected sockets
let hotspotIntervals = new Map();

function initializeSocket(server) {
    io = socketIo(server, {
        cors: {
            origin: '*',
            methods: ['GET', 'POST'],
        },
    });

    io.on('connection', (socket) => {
        console.log(`Client connected: ${socket.id}`);
        connectedSockets.set(socket.id, { id: socket.id, type: 'unknown' });

        // Handle test connection event
        socket.on('test-connection', (data) => {
            console.log(`Test connection from socket ${socket.id}:`, data);
            socket.emit('test-connection-response', { 
                message: 'Connection test successful', 
                socketId: socket.id,
                timestamp: new Date().toISOString()
            });
        });

        // Handle driver joining
        socket.on('join', async (data) => {
            const { userId, userType } = data;
            console.log(`Socket ${socket.id} joining as ${userType} with ID ${userId}`);

            try {
                if (userType === 'user') {
                    await userModel.findByIdAndUpdate(userId, { socketId: socket.id });
                    connectedSockets.set(socket.id, { id: socket.id, type: 'user', userId });
                    console.log(`User ${userId} connected with socket ID ${socket.id}`);
                } else if (userType === 'captain') {
                    // Update captain's socket ID in database
                    await captainModel.findByIdAndUpdate(userId, { 
                        socketId: socket.id,
                        status: 'active'  // Mark captain as active when they connect
                    });
                    connectedSockets.set(socket.id, { id: socket.id, type: 'captain', userId });
                    console.log(`Captain ${userId} connected with socket ID ${socket.id}`);

                    // Send initial hotspots to captain
                    try {
                        const hotspots = await mapService.detectHotspots();
                        console.log(`Sending initial ${hotspots.length} hotspots to captain ${userId}`);
                        socket.emit('hotspots-update', { hotspots });

                        // Set up interval to send hotspot updates every 5 seconds
                        const intervalId = setInterval(async () => {
                            try {
                                const updatedHotspots = await mapService.detectHotspots();
                                socket.emit('hotspots-update', { hotspots: updatedHotspots });
                            } catch (error) {
                                console.error('Error sending hotspot updates:', error);
                            }
                        }, 5000);

                        hotspotIntervals.set(socket.id, intervalId);
                    } catch (error) {
                        console.error('Error sending initial hotspots:', error);
                    }
                }
            } catch (error) {
                console.error(`Error updating socket ID for ${userType} ${userId}:`, error);
                socket.emit('error', { message: 'Failed to join' });
            }
        });

        // Handle driver location updates
        socket.on('update-location-captain', async (data) => {
            const socketInfo = connectedSockets.get(socket.id);
            if (!socketInfo || socketInfo.type !== 'captain') {
                return socket.emit('error', { message: 'Not authorized as captain' });
            }

            const { location } = data;
            if (!location || !location.ltd || !location.lng) {
                return socket.emit('error', { message: 'Invalid location data' });
            }

            try {
                await captainModel.findByIdAndUpdate(socketInfo.userId, {
                    location: {
                        ltd: location.ltd,
                        lng: location.lng,
                    },
                    lastLocationUpdate: new Date()
                });
                console.log(`Updated location for captain ${socketInfo.userId}: ${location.ltd}, ${location.lng}`);
            } catch (error) {
                console.error(`Error updating location for captain ${socketInfo.userId}:`, error);
                socket.emit('error', { message: 'Failed to update location' });
            }
        });

        // Handle driver requesting hotspots
        socket.on('request-hotspots', async (data) => {
            const socketInfo = connectedSockets.get(socket.id);
            if (!socketInfo || socketInfo.type !== 'captain') {
                return socket.emit('error', { message: 'Not authorized as captain' });
            }

            try {
                const hotspots = await mapService.detectHotspots();
                console.log(`Sending ${hotspots.length} hotspots to captain ${socketInfo.userId}`);
                socket.emit('hotspots-update', { hotspots }); // Send hotspots as an object
            } catch (err) {
                console.error('Error fetching hotspots:', err);
                socket.emit('error', { message: 'Failed to fetch hotspots' });
            }
        });

        // Handle disconnection
        socket.on('disconnect', () => {
            console.log(`Client disconnected: ${socket.id}`);
            const socketInfo = connectedSockets.get(socket.id);
            
            if (socketInfo) {
                if (socketInfo.type === 'captain') {
                    // Update captain status to inactive
                    captainModel.findByIdAndUpdate(socketInfo.userId, { 
                        status: 'inactive',
                        socketId: null
                    }).catch(err => {
                        console.error(`Error updating captain status on disconnect:`, err);
                    });

                    // Clear hotspot update interval
                    const intervalId = hotspotIntervals.get(socket.id);
                    if (intervalId) {
                        clearInterval(intervalId);
                        hotspotIntervals.delete(socket.id);
                    }
                } else if (socketInfo.type === 'user') {
                    // Clear user's socket ID
                    userModel.findByIdAndUpdate(socketInfo.userId, { 
                        socketId: null
                    }).catch(err => {
                        console.error(`Error updating user socket ID on disconnect:`, err);
                    });
                }
            }
            
            connectedSockets.delete(socket.id);
        });
    });

    // Log connected sockets and hotspot intervals every 30 seconds
    setInterval(() => {
        console.log(`Connected sockets (${connectedSockets.size}):`);
        connectedSockets.forEach((socketInfo) => {
            console.log(`- Socket ID: ${socketInfo.id}, Type: ${socketInfo.type}, User ID: ${socketInfo.userId || 'N/A'}`);
        });
        console.log(`Active hotspot intervals: ${hotspotIntervals.size}`);
    }, 30000);

    return io;
}

// Function to send a message to a specific socket ID
function sendMessageToSocketId(socketId, message) {
    if (!io) {
        console.error('Socket.io not initialized');
        return;
    }
    
    if (!socketId) {
        console.error('No socket ID provided');
        return;
    }
    
    try {
        console.log(`Sending message to socket ${socketId}:`, message);
        const socket = io.sockets.sockets.get(socketId);
        if (socket) {
            socket.emit(message.event, message.data);
            console.log(`Message sent successfully to socket ${socketId}`);
        } else {
            console.error(`Socket ${socketId} not found in active connections`);
        }
    } catch (error) {
        console.error(`Error sending message to socket ${socketId}:`, error);
    }
}

// Function to broadcast a message to all connected sockets of a specific type
function broadcastToType(type, message) {
    if (!io) {
        console.error('Socket.io not initialized');
        return;
    }
    
    try {
        console.log(`Broadcasting message to all ${type}s:`, message);
        let count = 0;
        connectedSockets.forEach((socketInfo, socketId) => {
            if (socketInfo.type === type) {
                const socket = io.sockets.sockets.get(socketId);
                if (socket) {
                    socket.emit(message.event, message.data);
                    count++;
                }
            }
        });
        console.log(`Message broadcast to ${count} ${type}s`);
    } catch (error) {
        console.error(`Error broadcasting message to ${type}s:`, error);
    }
}

// Function to get all connected sockets
function getConnectedSockets() {
    return Array.from(connectedSockets.values());
}

module.exports = { 
    initializeSocket,
    sendMessageToSocketId,
    broadcastToType,
    getConnectedSockets
};