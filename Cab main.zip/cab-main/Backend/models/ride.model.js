const mongoose = require('mongoose');

const rideSchema = new mongoose.Schema({
    user: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'user',
        required: true
    },
    captain: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'captain'
    },
    pickup: {
        address: {
            type: String,
            required: true
        },
        location: {
            lat: Number,
            lng: Number
        }
    },
    destination: {
        address: {
            type: String,
            required: true
        },
        location: {
            lat: Number,
            lng: Number
        }
    },
    fare: {
        type: Number,
        required: true
    },
    vehicleType: {
        type: String,
        required: true,
        enum: ['auto', 'car', 'bike']
    },
    status: {
        type: String,
        required: true,
        enum: ['pending', 'accepted', 'started', 'completed', 'cancelled'],
        default: 'pending'
    },
    otp: {
        type: String,
        default: () => Math.floor(100000 + Math.random() * 900000).toString()
    },
    createdAt: {
        type: Date,
        default: Date.now
    },
    acceptedAt: Date,
    startedAt: Date,
    completedAt: Date
});

module.exports = mongoose.model('Ride', rideSchema);