/**
 * DBSCAN (Density-Based Spatial Clustering of Applications with Noise) implementation
 * for clustering ride requests based on their locations.
 */

// Calculate distance between two points using Haversine formula
function calculateDistance(point1, point2) {
    const [lat1, lng1] = point1;
    const [lat2, lng2] = point2;
    
    const R = 6371; // Earth's radius in kilometers
    const dLat = toRad(lat2 - lat1);
    const dLng = toRad(lng2 - lng1);
    
    const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
              Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * 
              Math.sin(dLng/2) * Math.sin(dLng/2);
    
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return R * c; // Distance in kilometers
}

function toRad(degrees) {
    return degrees * (Math.PI/180);
}

// Find neighbors within eps distance
function getNeighbors(point, points, eps) {
    return points.reduce((neighbors, otherPoint, index) => {
        if (point !== otherPoint && calculateDistance(point, otherPoint) <= eps) {
            neighbors.push(index);
        }
        return neighbors;
    }, []);
}

/**
 * DBSCAN clustering algorithm
 * @param {Array} points Array of points to cluster, each point should be [lat, lng]
 * @param {number} eps Maximum distance between two points for them to be considered neighbors
 * @param {number} minPoints Minimum number of points required to form a dense region
 * @returns {Array} Array of clusters, where each cluster is an array of points
 */
function dbscan(points, eps, minPoints) {
    if (!Array.isArray(points) || points.length === 0) {
        console.log('No points provided for clustering');
        return [];
    }

    const visited = new Set();
    const noise = new Set();
    const clusters = [];
    let currentCluster = [];

    // Process each point
    points.forEach((point, index) => {
        if (visited.has(index)) return;
        
        visited.add(index);
        const neighbors = getNeighbors(point, points, eps);

        if (neighbors.length < minPoints) {
            noise.add(index);
            return;
        }

        // Start a new cluster
        currentCluster = [point];
        clusters.push(currentCluster);

        // Process neighbors
        const queue = [...neighbors];
        while (queue.length > 0) {
            const currentIndex = queue.shift();
            
            if (!visited.has(currentIndex)) {
                visited.add(currentIndex);
                const currentNeighbors = getNeighbors(points[currentIndex], points, eps);
                
                if (currentNeighbors.length >= minPoints) {
                    queue.push(...currentNeighbors.filter(n => !visited.has(n)));
                }
            }

            if (!noise.has(currentIndex)) {
                currentCluster.push(points[currentIndex]);
            }
        }
    });

    // Handle noise points as individual clusters
    noise.forEach(index => {
        clusters.push([points[index]]);
    });

    return clusters;
}

module.exports = dbscan; 