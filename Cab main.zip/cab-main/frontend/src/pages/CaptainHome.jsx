import React, { useRef, useState, useEffect, useContext } from 'react';
import { Link } from 'react-router-dom';
import CaptainDetails from '../components/CaptainDetails';
import RidePopUp from '../components/RidePopUp';
import { useGSAP } from '@gsap/react';
import gsap from 'gsap';
import ConfirmRidePopUp from '../components/ConfirmRidePopUp';
import { SocketContext } from '../context/SocketContext';
import { CaptainDataContext } from '../context/CapatainContext';
import axios from 'axios';
import LiveTracking from '../components/LiveTracking';

const CaptainHome = () => {
    const [ridePopupPanel, setRidePopupPanel] = useState(false);
    const [confirmRidePopupPanel, setConfirmRidePopupPanel] = useState(false);
    const ridePopupPanelRef = useRef(null);
    const confirmRidePopupPanelRef = useRef(null);
    const [ride, setRide] = useState(null);

    const { socket } = useContext(SocketContext);
    const { captain } = useContext(CaptainDataContext);

    // Request hotspots when the component mounts
    useEffect(() => {
        if (socket && captain && captain._id) {
            console.log('Requesting initial hotspots');
            socket.emit('request-hotspots', { captainId: captain._id });
        }
    }, [socket, captain]);

    // Handle new ride requests
    useEffect(() => {
        if (socket) {
            console.log("Setting up new-ride event listener");
            
            // Remove any existing listeners to prevent duplicates
            socket.off('new-ride');
            
            socket.on('new-ride', (data) => {
                console.log("Received new ride notification:", data);
                if (data && data.ride) {
                    setRide(data.ride);
                    setRidePopupPanel(true);
                    // Play a notification sound
                    const audio = new Audio('/notification.mp3');
                    audio.play().catch(err => console.log('Error playing notification:', err));
                } else {
                    console.error("Invalid ride data received:", data);
                }
            });
            
            // Test if the socket is working
            socket.emit('test-connection', { message: 'Testing connection from captain app' });
        } else {
            console.error("Socket is not available for ride notifications");
        }

        return () => {
            if (socket) {
                console.log("Cleaning up new-ride event listener");
                socket.off('new-ride');
            }
        };
    }, [socket]);

    // Join the socket room when captain is logged in
    useEffect(() => {
        if (socket && captain && captain._id) {
            console.log(`Captain ${captain._id} joining socket room`);
            socket.emit('join', { userType: 'captain', userId: captain._id });

            // Start sending location updates
            const updateLocation = () => {
                if (navigator.geolocation) {
                    navigator.geolocation.getCurrentPosition(
                        (position) => {
                            socket.emit('update-location-captain', {
                                location: {
                                    ltd: position.coords.latitude,
                                    lng: position.coords.longitude,
                                },
                            });
                        },
                        (error) => {
                            console.error('Error getting location:', error);
                        }
                    );
                }
            };

            // Update location immediately and then every 10 seconds
            updateLocation();
            const locationInterval = setInterval(updateLocation, 10000);

            return () => {
                clearInterval(locationInterval);
            };
        }
    }, [socket, captain]);

    // GSAP animations for ride popup
    useGSAP(() => {
        if (ridePopupPanel) {
            gsap.to(ridePopupPanelRef.current, {
                transform: 'translateY(0)',
                duration: 0.3,
                ease: 'power2.out'
            });
        } else {
            gsap.to(ridePopupPanelRef.current, {
                transform: 'translateY(100%)',
                duration: 0.3,
                ease: 'power2.in'
            });
        }
    }, [ridePopupPanel]);

    // GSAP animations for confirm ride popup
    useGSAP(() => {
        if (confirmRidePopupPanel) {
            gsap.to(confirmRidePopupPanelRef.current, {
                transform: 'translateY(0)',
                duration: 0.3,
                ease: 'power2.out'
            });
        } else {
            gsap.to(confirmRidePopupPanelRef.current, {
                transform: 'translateY(100%)',
                duration: 0.3,
                ease: 'power2.in'
            });
        }
    }, [confirmRidePopupPanel]);

    // Confirm ride handler
    const handleConfirmRide = async () => {
        try {
            console.log('Confirming ride:', ride?._id);
            const response = await axios.post(
                `${import.meta.env.VITE_API_URL}/rides/confirm`,
                { rideId: ride._id },
                {
                    headers: {
                        Authorization: `Bearer ${localStorage.getItem('token')}`
                    }
                }
            );
            
            if (response.status === 200) {
                console.log('Ride confirmed successfully:', response.data);
                setRide(response.data);
                setRidePopupPanel(false);
                setConfirmRidePopupPanel(true);
            }
        } catch (error) {
            console.error('Error confirming ride:', error);
            alert(error.response?.data?.message || 'Failed to confirm ride');
        }
    };

    return (
        <div className="h-screen">
            <div className="fixed p-6 top-0 flex items-center justify-between w-screen">
                <img
                    className="w-16"
                    src="https://upload.wikimedia.org/wikipedia/commons/c/cc/Uber_logo_2018.png"
                    alt=""
                />
                <Link
                    to="/captain-home"
                    className="h-10 w-10 bg-white flex items-center justify-center rounded-full"
                >
                    <i className="text-lg font-medium ri-logout-box-r-line"></i>
                </Link>
            </div>
            <div className="h-3/5">
                <LiveTracking />
            </div>
            <div className="h-2/5 p-6">
                <CaptainDetails />
            </div>
            <div
                ref={ridePopupPanelRef}
                className="fixed w-full z-10 bottom-0 translate-y-full bg-white px-3 py-10 pt-12"
            >
                <RidePopUp
                    ride={ride}
                    setRidePopupPanel={setRidePopupPanel}
                    setConfirmRidePopupPanel={setConfirmRidePopupPanel}
                    confirmRide={handleConfirmRide}
                />
            </div>
            <div
                ref={confirmRidePopupPanelRef}
                className="fixed w-full h-screen z-10 bottom-0 translate-y-full bg-white px-3 py-10 pt-12"
            >
                <ConfirmRidePopUp
                    ride={ride}
                    setConfirmRidePopupPanel={setConfirmRidePopupPanel}
                    setRidePopupPanel={setRidePopupPanel}
                />
            </div>
        </div>
    );
};

export default CaptainHome;