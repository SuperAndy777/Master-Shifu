import React, { useContext, useEffect, useState } from 'react'
import { UserDataContext } from '../context/UserContext'
import { useNavigate } from 'react-router-dom'
import axios from 'axios'

const UserProtectWrapper = ({
    children
}) => {
    const token = localStorage.getItem('token')
    const navigate = useNavigate()
    const { user, setUser } = useContext(UserDataContext)
    const [ isLoading, setIsLoading ] = useState(true)

    useEffect(() => {
        const fetchProfile = async () => {
            setIsLoading(true)
            const token = localStorage.getItem('token')

            if (!token) {
                console.log('No token found, redirecting to login')
                setIsLoading(false)
                navigate('/login')
                return
            }

            try {
                const response = await axios.get(`${import.meta.env.VITE_API_URL}/users/profile`, {
                    headers: {
                        Authorization: `Bearer ${token}`
                    }
                })

                if (response.status === 200) {
                    console.log('User profile loaded:', response.data)
                    setUser(response.data)
                }
                setIsLoading(false)
            } catch (error) {
                console.error('Error fetching user profile:', error)
                // Clear token only if it's an authentication error
                if (error.response && (error.response.status === 401 || error.response.status === 403)) {
                    console.log('Authentication error, clearing token')
                    localStorage.removeItem('token')
                }
                setIsLoading(false)
                navigate('/login')
            }
        }

        fetchProfile()
    }, [navigate, setUser])

    if (isLoading) {
        return (
            <div className="flex items-center justify-center h-screen">
                <div className="text-center">
                    <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-gray-900 mx-auto"></div>
                    <p className="mt-4 text-lg">Loading user profile...</p>
                </div>
            </div>
        )
    }

    return (
        <>
            {children}
        </>
    )
}

export default UserProtectWrapper