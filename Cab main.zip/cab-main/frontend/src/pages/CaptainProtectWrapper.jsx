import React, { useContext, useEffect, useState } from 'react'
import { CaptainDataContext } from '../context/CapatainContext'
import { useNavigate } from 'react-router-dom'
import axios from 'axios'

const CaptainProtectWrapper = ({
    children
}) => {

    const token = localStorage.getItem('token')
    const navigate = useNavigate()
    const { captain, setCaptain } = useContext(CaptainDataContext)
    const [ isLoading, setIsLoading ] = useState(true)

    useEffect(() => {
        const fetchProfile = async () => {
            setIsLoading(true)
            const token = localStorage.getItem('token')

            if (!token) {
                setIsLoading(false)
                navigate('/captain-login')
                return
            }

            try {
                const response = await axios.get(`${import.meta.env.VITE_API_URL}/captains/profile`, {
                    headers: {
                        Authorization: `Bearer ${token}`
                    }
                })

                if (response.status === 200) {
                    // Check if the response contains captain data
                    if (response.data && response.data.captain) {
                        setCaptain(response.data.captain)
                        console.log("Captain data loaded:", response.data.captain)
                    } else {
                        console.error('Invalid captain data format:', response.data)
                        throw new Error('Invalid captain data format')
                    }
                }
                setIsLoading(false)
            } catch (error) {
                console.error('Error fetching captain profile:', error)
                localStorage.removeItem('token')
                setIsLoading(false)
                navigate('/captain-login')
            }
        }

        fetchProfile()
    }, [navigate, setCaptain])

    if (isLoading) {
        return (
            <div className="flex items-center justify-center h-screen">
                <div className="text-center">
                    <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-gray-900 mx-auto"></div>
                    <p className="mt-4 text-lg">Loading captain profile...</p>
                </div>
            </div>
        )
    }

    return (
        <>
            {children}
        </>
    )
}

export default CaptainProtectWrapper