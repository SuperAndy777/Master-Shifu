import React, { createContext, useEffect, useState } from 'react';
import { io } from 'socket.io-client';

export const SocketContext = createContext();

// Use environment variable for API URL
const socket = io(import.meta.env.VITE_API_URL || 'http://localhost:5123');

const SocketProvider = ({ children }) => {
    const [hotspots, setHotspots] = useState([]);
    const [isConnected, setIsConnected] = useState(false);

    useEffect(() => {
        // Basic connection logic
        socket.on('connect', () => {
            console.log('Connected to server');
            setIsConnected(true);
        });

        socket.on('disconnect', () => {
            console.log('Disconnected from server');
            setIsConnected(false);
        });

        socket.on('connect_error', (error) => {
            console.error('Connection error:', error);
            setIsConnected(false);
        });

        // Listen for hotspot updates from the backend
        socket.on('hotspots-update', (data) => {
            console.log('Received hotspot update:', data);
            if (data && Array.isArray(data.hotspots)) {
                setHotspots(data.hotspots);
            } else {
                console.error('Invalid hotspots data received:', data);
            }
        });

        // Test connection when component mounts
        socket.emit('test-connection', { message: 'Testing connection from client' });

        // Log all events for debugging
        socket.onAny((event, ...args) => {
            console.log(`Socket event: ${event}`, args);
        });

        return () => {
            socket.off('connect');
            socket.off('disconnect');
            socket.off('connect_error');
            socket.off('hotspots-update');
        };
    }, []);

    return (
        <SocketContext.Provider value={{ socket, isConnected, hotspots }}>
            {children}
        </SocketContext.Provider>
    );
};

export default SocketProvider;