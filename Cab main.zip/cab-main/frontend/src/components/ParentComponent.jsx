import React, { useState } from 'react';
import ConfirmRide from './ConfirmRide';

const ParentComponent = () => {
    const [confirmRidePanel, setConfirmRidePanel] = useState(false);

    const createRide = async () => {
        // Logic to create a ride
        console.log("Ride created");
        setConfirmRidePanel(false); // Close the panel after creating the ride
    };

    return (
        <div>
            <button onClick={() => setConfirmRidePanel(true)}>Show Confirm Ride</button>
            {confirmRidePanel && (
                <ConfirmRide 
                    setConfirmRidePanel={setConfirmRidePanel}
                    createRide={createRide}
                    fare={{ car: "199.00", moto: "99.00", auto: "149.00" }}
                    vehicleType="car"
                    pickup="123 Main St"
                    destination="456 Elm St"
                />
            )}
        </div>
    );
};

export default ParentComponent;