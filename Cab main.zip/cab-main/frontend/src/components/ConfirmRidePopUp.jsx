import React, { useState } from 'react'
import { Link } from 'react-router-dom'
import axios from 'axios'
import { useNavigate } from 'react-router-dom'

const ConfirmRidePopUp = ({ ride, setConfirmRidePopupPanel, setRidePopupPanel }) => {
    const [otp, setOtp] = useState('')
    const [loading, setLoading] = useState(false)
    const [error, setError] = useState('')
    const navigate = useNavigate()

    const handleStartRide = async () => {
        if (!otp || otp.length !== 6) {
            setError('Please enter a valid 6-digit OTP')
            return
        }

        setLoading(true)
        setError('')

        try {
            const response = await axios.get(
                `${import.meta.env.VITE_API_URL}/rides/start-ride`,
                {
                    params: {
                        rideId: ride._id,
                        otp: otp
                    },
                    headers: {
                        Authorization: `Bearer ${localStorage.getItem('token')}`
                    }
                }
            )

            console.log('Ride started successfully:', response.data)
            setConfirmRidePopupPanel(false)
            
            // Navigate to the navigation page with ride details
            navigate('/navigation', { 
                state: { 
                    ride: response.data.ride,
                    pickup: response.data.ride.pickup,
                    destination: response.data.ride.destination
                } 
            })
        } catch (error) {
            console.error('Error starting ride:', error)
            setError(error.response?.data?.message || 'Failed to start ride. Please try again.')
        } finally {
            setLoading(false)
        }
    }

    return (
        <div className="h-full flex flex-col justify-between">
            <div>
                <div className="flex items-center justify-between">
                    <h1 className="text-2xl font-medium">Confirm Ride</h1>
                    <button
                        onClick={() => {
                            setConfirmRidePopupPanel(false)
                            setRidePopupPanel(false)
                        }}
                        className="h-10 w-10 rounded-full bg-gray-100 flex items-center justify-center"
                    >
                        <i className="ri-close-line"></i>
                    </button>
                </div>
                <div className="mt-6">
                    <label className="text-sm text-gray-600">Enter OTP from User</label>
                    <input
                        type="text"
                        value={otp}
                        onChange={(e) => {
                            const value = e.target.value.replace(/[^0-9]/g, '')
                            if (value.length <= 6) setOtp(value)
                        }}
                        placeholder="Enter 6-digit OTP"
                        className="w-full h-12 border rounded-lg px-4 mt-2"
                        maxLength={6}
                    />
                    {error && (
                        <p className="text-red-500 text-sm mt-2">{error}</p>
                    )}
                </div>
            </div>
            <button
                onClick={handleStartRide}
                disabled={loading || !otp || otp.length !== 6}
                className={`w-full h-12 rounded-lg ${
                    loading || !otp || otp.length !== 6
                        ? 'bg-gray-300'
                        : 'bg-black text-white'
                }`}
            >
                {loading ? 'Starting Ride...' : 'Start Ride'}
            </button>
        </div>
    )
}

export default ConfirmRidePopUp