import React, { useState } from 'react'
import axios from 'axios'

const RidePopUp = (props) => {
    const [loading, setLoading] = useState(false)
    const [error, setError] = useState('')

    const handleConfirmRide = async () => {
        setLoading(true)
        setError('')

        try {
            console.log(`Confirming ride ${props.ride?._id}`);
            const response = await axios.post(`${import.meta.env.VITE_API_URL}/rides/confirm`, 
                { rideId: props.ride._id },
                {
                    headers: {
                        Authorization: `Bearer ${localStorage.getItem('token')}`
                    }
                }
            );

            if (response.status === 200) {
                console.log('Ride confirmed successfully:', response.data);
                props.setConfirmRidePopupPanel(true);
                // Don't close the ride popup panel yet as we need to enter OTP
            }
        } catch (error) {
            console.error('Error confirming ride:', error);
            let errorMessage = 'Failed to confirm ride. Please try again.';
            
            if (error.response) {
                console.error('Error response:', error.response.data);
                errorMessage = error.response.data.message || errorMessage;
                
                if (error.response.status === 401) {
                    errorMessage = 'Please log in again to continue.';
                } else if (error.response.status === 404) {
                    errorMessage = 'Ride not found or already taken by another captain.';
                }
            } else if (error.request) {
                console.error('No response received:', error.request);
                errorMessage = 'No response from server. Please check your internet connection.';
            }
            
            setError(errorMessage);
        } finally {
            setLoading(false);
        }
    };

    return (
        <div>
            <h5 className='p-1 text-center w-[93%] absolute top-0' onClick={() => {
                props.setRidePopupPanel(false)
            }}><i className="text-3xl text-gray-200 ri-arrow-down-wide-line"></i></h5>
            <h3 className='text-2xl font-semibold mb-5'>New Ride Available!</h3>
            <div className='flex items-center justify-between p-3 bg-yellow-400 rounded-lg mt-4'>
                <div className='flex items-center gap-3 '>
                    <img className='h-12 rounded-full object-cover w-12' src="https://i.pinimg.com/236x/af/26/28/af26280b0ca305be47df0b799ed1b12b.jpg" alt="" />
                    <h2 className='text-lg font-medium'>{props.ride?.user?.fullname?.firstname || 'User'}</h2>
                </div>
                <h5 className='text-lg font-semibold'>₹{props.ride?.fare || 0}</h5>
            </div>
            <div className='flex gap-2 justify-between flex-col items-center'>
                <div className='w-full mt-5'>
                    <div className='flex items-center gap-5 p-3 border-b-2'>
                        <i className="ri-map-pin-user-fill"></i>
                        <div>
                            <h3 className='text-lg font-medium'>Pickup Location</h3>
                            <p className='text-sm -mt-1 text-gray-600'>{props.ride?.pickup?.address || 'Loading...'}</p>
                        </div>
                    </div>
                    <div className='flex items-center gap-5 p-3 border-b-2'>
                        <i className="text-lg ri-map-pin-2-fill"></i>
                        <div>
                            <h3 className='text-lg font-medium'>Destination</h3>
                            <p className='text-sm -mt-1 text-gray-600'>{props.ride?.destination?.address || 'Loading...'}</p>
                        </div>
                    </div>
                    <div className='flex items-center gap-5 p-3'>
                        <i className="ri-car-line"></i>
                        <div>
                            <h3 className='text-lg font-medium'>{props.ride?.vehicleType || 'Auto'}</h3>
                            <p className='text-sm -mt-1 text-gray-600'>Vehicle Type</p>
                        </div>
                    </div>
                    <div className='flex items-center gap-5 p-3'>
                        <i className="ri-currency-line"></i>
                        <div>
                            <h3 className='text-lg font-medium'>₹{props.ride?.fare || 0}</h3>
                            <p className='text-sm -mt-1 text-gray-600'>Cash Payment</p>
                        </div>
                    </div>
                </div>
                <div className='mt-5 w-full'>
                    {error && <p className="text-red-500 text-center mb-3">{error}</p>}
                    <button 
                        onClick={handleConfirmRide}
                        disabled={loading}
                        className={`w-full ${loading ? 'bg-gray-500' : 'bg-green-600'} text-white font-semibold p-2 px-10 rounded-lg`}
                    >
                        {loading ? 'Accepting...' : 'Accept'}
                    </button>

                    <button 
                        onClick={() => {
                            props.setRidePopupPanel(false)
                        }} 
                        disabled={loading}
                        className='mt-2 w-full bg-gray-300 text-gray-700 font-semibold p-2 px-10 rounded-lg'
                    >
                        Ignore
                    </button>
                </div>
            </div>
        </div>
    )
}

export default RidePopUp