import React, { useState, useEffect, useContext } from 'react';
import { LoadScript, GoogleMap, Circle } from '@react-google-maps/api';
import { SocketContext } from '../context/SocketContext'; // Import SocketContext

const containerStyle = {
    width: '100%',
    height: '100%',
};

const center = {
    lat: -3.745,
    lng: -38.523,
};

const circleOptions = {
    fillColor: '#FFA500', // Light orange fill
    fillOpacity: 0.4,
    strokeColor: '#FF8C00', // Dark orange border
    strokeOpacity: 0.8,
    strokeWeight: 2,
};

// Custom marker component to avoid the deprecation warning
const CustomMarker = ({ position }) => {
    return (
        <div 
            style={{
                position: 'absolute',
                transform: 'translate(-50%, -100%)',
                background: '#4285F4',
                borderRadius: '50%',
                padding: '8px',
                boxShadow: '0 2px 6px rgba(0,0,0,0.3)',
            }}
        >
            <div 
                style={{
                    width: '16px',
                    height: '16px',
                    background: 'white',
                    borderRadius: '50%',
                }}
            />
        </div>
    );
};

// Fallback component when Google Maps fails to load
const MapFallback = () => {
    return (
        <div style={{ 
            width: '100%', 
            height: '100%', 
            display: 'flex', 
            justifyContent: 'center', 
            alignItems: 'center',
            backgroundColor: '#f0f0f0',
            flexDirection: 'column'
        }}>
            <div style={{ fontSize: '24px', marginBottom: '10px' }}>Map Unavailable</div>
            <div style={{ fontSize: '16px', color: '#666', textAlign: 'center', padding: '0 20px' }}>
                We're having trouble loading the map. Please check your internet connection.
            </div>
        </div>
    );
};

const LiveTracking = () => {
    const [currentPosition, setCurrentPosition] = useState(center);
    const [hotspots, setHotspots] = useState([]); // State for hotspots
    const [mapError, setMapError] = useState(false); // Track map loading errors
    const { socket } = useContext(SocketContext); // Access WebSocket

    // Get current location and watch for updates
    useEffect(() => {
        navigator.geolocation.getCurrentPosition(
            (position) => {
                const { latitude, longitude } = position.coords;
                setCurrentPosition({
                    lat: latitude,
                    lng: longitude,
                });
            },
            (error) => {
                console.error("Geolocation error:", error);
                // Keep the default center if geolocation fails
            }
        );

        const watchId = navigator.geolocation.watchPosition(
            (position) => {
                const { latitude, longitude } = position.coords;
                setCurrentPosition({
                    lat: latitude,
                    lng: longitude,
                });
            },
            (error) => {
                console.error("Geolocation watch error:", error);
            }
        );

        return () => navigator.geolocation.clearWatch(watchId);
    }, []);

    // Listen for hotspot updates from the WebSocket server
    useEffect(() => {
        if (socket) {
            socket.on('hotspots-update', (data) => {
                if (data && data.hotspots) {
                    setHotspots(data.hotspots); // Update hotspots
                }
            });
        }

        return () => {
            if (socket) {
                socket.off('hotspots-update'); // Cleanup listener
            }
        };
    }, [socket]);

    // Handle Google Maps API loading error
    const handleMapError = () => {
        console.error("Google Maps failed to load");
        setMapError(true);
    };

    // If map failed to load, show fallback UI
    if (mapError) {
        return <MapFallback />;
    }

    return (
        <LoadScript 
            googleMapsApiKey={import.meta.env.VITE_GOOGLE_MAPS_API_KEY || ''}
            onError={handleMapError}
            loadingElement={<div style={{ height: '100%' }}>Loading Maps...</div>}
        >
            <GoogleMap
                mapContainerStyle={containerStyle}
                center={currentPosition}
                zoom={15}
                onLoad={() => console.log("Map loaded successfully")}
                onError={handleMapError}
            >
                {/* Use a div with position absolute instead of Marker */}
                <div style={{ position: 'absolute', left: '50%', top: '50%' }}>
                    <CustomMarker position={currentPosition} />
                </div>
                
                {hotspots && hotspots.length > 0 && hotspots.map((hotspot, index) => (
                    <Circle
                        key={index}
                        center={hotspot.center}
                        radius={hotspot.radius}
                        options={{
                            ...circleOptions,
                            fillOpacity: hotspot.intensity || 0.4,
                            fillColor: '#FF0000', // Red for ride requests
                            strokeColor: '#FF0000'
                        }}
                    />
                ))}
            </GoogleMap>
        </LoadScript>
    );
};

export default LiveTracking;